#ifndef DEVICEMANAGER_H
#define DEVICEMANAGER_H

#include "base/deviceitemsmodel.h"
#include <QDialog>
#include <QIcon>

class QDialogButtonBox;
class QLabel;
class QLineEdit;
class QListView;

class DeviceManager : public QDialog
{
    Q_OBJECT

public:
    explicit DeviceManager(QWidget *parent = nullptr);

    static Device selectDevice(const QString &title = QString(),
                               const QString &action = QString(),
                               const QIcon &icon = QIcon(),
                               QWidget *parent = nullptr);

signals:
    void currentChanged(const Device &device);

private:
    bool setCurrentDevice(const Device &device);

    QListView *deviceList;
    DeviceItemsModel deviceModel;

    QLineEdit *fieldAlias;
    QLabel *labelSerial;
    QLabel *labelProduct;
    QLabel *labelModel;
    QLabel *labelDevice;

    QDialogButtonBox *dialogButtons;
};

#endif // DEVICEMANAGER_H
