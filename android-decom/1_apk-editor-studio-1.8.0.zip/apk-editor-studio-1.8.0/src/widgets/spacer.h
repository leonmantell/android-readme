#ifndef SPACER_H
#define SPACER_H

#include <QWidget>

class Spacer : public QWidget
{
    Q_OBJECT

public:
    explicit Spacer(QWidget *parent = nullptr);
};

#endif // SPACER_H
