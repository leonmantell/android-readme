Refer to the following instructions to modify and use to generate SmaliTokenMarker

```shell
jflex SmaliTokenMaker.flex --skel skeleton.default
```
