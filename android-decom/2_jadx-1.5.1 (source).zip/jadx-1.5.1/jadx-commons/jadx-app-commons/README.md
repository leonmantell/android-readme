## jadx app commons

This module contains common utilities used in jadx apps (cli and gui) and not needed in jadx-code module:
- `JadxCommonFiles` - wrapper for `dev.dirs:directories` lib to get
  'config' and 'cache' directories in cross-platform way
- `JadxCommonEnv` - utils for work with environment variables
