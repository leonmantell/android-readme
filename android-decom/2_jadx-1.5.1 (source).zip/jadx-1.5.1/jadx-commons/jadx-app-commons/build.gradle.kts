plugins {
	id("jadx-library")
}

dependencies {
	implementation("dev.dirs:directories:26")
}
