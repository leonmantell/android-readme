package jadx.api.plugins.options;

public enum OptionType {
	STRING,
	NUMBER,
	BOOLEAN
}
