package jadx.core.dex.nodes;

public interface IPackageUpdate {

	void onParentPackageUpdate(PackageNode updatedPkg);
}
