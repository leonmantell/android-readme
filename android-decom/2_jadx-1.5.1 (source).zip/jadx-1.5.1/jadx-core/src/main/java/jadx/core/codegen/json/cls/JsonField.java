package jadx.core.codegen.json.cls;

public class JsonField extends JsonNode {
	String type;
}
