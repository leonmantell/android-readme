Only support GDA3.75+, Other version do not use this theme file. 
Usage:
click on menu `File`->`Import Color Config`,choosing a theme file and reboot GDA.
